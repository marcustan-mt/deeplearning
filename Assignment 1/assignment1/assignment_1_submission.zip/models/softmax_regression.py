""" 			  		 			     			  	   		   	  			  	
Softmax Regression Model.  (c) 2021 Georgia Tech

Copyright 2021, Georgia Institute of Technology (Georgia Tech)
Atlanta, Georgia 30332
All Rights Reserved

Template code for CS 7643 Deep Learning

Georgia Tech asserts copyright ownership of this template and all derivative
works, including solutions to the projects assigned in this course. Students
and other users of this template code are advised not to share it with others
or to make it available on publicly viewable websites including repositories
such as Github, Bitbucket, and Gitlab.  This copyright statement should
not be removed or edited.

Sharing solutions with current or future students of CS 7643 Deep Learning is
prohibited and subject to being investigated as a GT honor code violation.

-----do not edit anything above this line---
"""

# Do not use packages that are not in standard distribution of python
import numpy as np

from ._base_network import _baseNetwork


class SoftmaxRegression(_baseNetwork):
    def __init__(self, input_size=28 * 28, num_classes=10):
        """
        A single layer softmax regression. The network is composed by:
        a linear layer without bias => (activation) => Softmax
        :param input_size: the input dimension
        :param num_classes: the number of classes in total
        """
        super().__init__(input_size, num_classes)
        self._weight_init()

    def _weight_init(self):
        '''
        initialize weights of the single layer regression network. No bias term included.
        :return: None; self.weights is filled based on method
        - W1: The weight matrix of the linear layer of shape (num_features, hidden_size)
        '''
        np.random.seed(1024)
        self.weights['W1'] = 0.001 * np.random.randn(self.input_size, self.num_classes)
        self.gradients['W1'] = np.zeros((self.input_size, self.num_classes))

    def forward(self, X, y, mode='train'):
        """
        Compute loss and gradients using softmax with vectorization.

        :param X: a batch of image (N, 28x28)
        :param y: labels of images in the batch (N,)
        :return:
            loss: the loss associated with the batch
            accuracy: the accuracy of the batch
        """
        loss = None
        gradient = None
        accuracy = None
        #############################################################################
        # TODO:                                                                     #
        #    1) Implement the forward process and compute the Cross-Entropy loss    #
        #    2) Compute the gradient of the loss with respect to the weights        #
        # Hint:                                                                     #
        #   Store your intermediate outputs before ReLU for backwards               #
        #############################################################################
        
        # This provides 64 rows x 10 of the classes score.
        result = np.dot(X,self.weights['W1'])

        # Apply ReLU; shape: 64x10
        relued = _baseNetwork.ReLU(self, result) 

        # Apply Softmax to get the probability; shape: 64x10
        softmaxed = _baseNetwork.softmax(self, relued)
        
        # Apply Cross Entropy; scalar
        loss = _baseNetwork.cross_entropy_loss(self,softmaxed,y)

        # Apply Accuracy; scalar
        accuracy = _baseNetwork.compute_accuracy(self,softmaxed,y)

        #############################################################################
        #                              END OF YOUR CODE                             #
        #############################################################################
        if mode != 'train':
            return loss, accuracy
        
        #############################################################################
        # TODO:                                                                     #
        #    1) Implement the backward process:                                     #
        #        1) Compute gradients of each weight by chain rule                  #
        #        2) Store the gradients in self.gradients                           #
        #############################################################################
        
        # We need to do a d(loss)/d(A) * d(A)/d(Z) * d(Z)/d(weights)
        # Loss = CE(Softmax[A],y)
        # A = ReLU(Z)
        # Z = WX^T
        
        # dL/dA
        for i in range(0,len(y)):
            softmaxed[i, y[i]] = softmaxed[i, y[i]] - 1
        
        # dA/dZ
        relu_deriv = self.ReLU_dev(result)
        grad = softmaxed * relu_deriv
        
        # dL/dW; While taking SGD into consideration
        input_transposed = np.transpose(X)
        batch_size = len(y)
        self.gradients['W1'] = np.dot(input_transposed, grad/batch_size)

        #############################################################################
        #                              END OF YOUR CODE                             #
        #############################################################################
        return loss, accuracy
