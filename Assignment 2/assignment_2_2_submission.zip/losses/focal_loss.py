"""
Focal Loss Wrapper.  (c) 2021 Georgia Tech

Copyright 2021, Georgia Institute of Technology (Georgia Tech)
Atlanta, Georgia 30332
All Rights Reserved

Template code for CS 7643 Deep Learning

Georgia Tech asserts copyright ownership of this template and all derivative
works, including solutions to the projects assigned in this course. Students
and other users of this template code are advised not to share it with others
or to make it available on publicly viewable websites including repositories
such as Github, Bitbucket, and Gitlab.  This copyright statement should
not be removed or edited.

Sharing solutions with current or future students of CS 7643 Deep Learning is
prohibited and subject to being investigated as a GT honor code violation.

-----do not edit anything above this line---
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np


def hello_do_you_copy():
    """
    This is a sample function that we will try to import and run to ensure that
    our environment is correctly set up on Google Colab.
    """
    print("Roger that from focal_loss.py!")


def reweight(cls_num_list, beta=0.9999):
    """
    Implement reweighting by effective numbers
    :param cls_num_list: a list containing # of samples of each class
    :param beta: hyper-parameter for reweighting, see paper for more details
    :return:
    """

    #############################################################################
    # TODO: reweight each class by effective numbers                            #
    #############################################################################
    per_cls_weights = None
    
    # Converting list to array and updating weights
    cls_num_arr = np.array(cls_num_list)
    weights = (1-beta)/(1-beta**cls_num_arr)

    # Apply normalization on alpha_i such that sum alpha_i (i to c) = C
    val = len(weights)
    sum_alpha_i = np.sum(weights)
    normalized_weights = weights * val/sum_alpha_i

    # Converting to torch
    per_cls_weights = torch.from_numpy(normalized_weights).float()

    #############################################################################
    #                              END OF YOUR CODE                             #
    #############################################################################
    return per_cls_weights


class FocalLoss(nn.Module):
    def __init__(self, weight=None, gamma=0.0):
        super().__init__()
        assert gamma >= 0
        self.gamma = gamma
        self.weight = weight

    def forward(self, input, target):
        """
        Implement forward of focal loss
        :param input: input predictions
        :param target: labels
        :return: tensor of focal loss in scalar
        """
        loss = None
        #############################################################################
        # TODO: Implement forward pass of the focal loss                            #
        #############################################################################
        # print('gamma',self.gamma)

        # # Calculating Alphas
        # cls_num_list = torch.bincount(target)
        # per_cls_weights = reweight(cls_num_list)

        # Calculating pt
        self.softmax = nn.Softmax(dim=1) 
        softmaxed = self.softmax(input) 
        pt = softmaxed[torch.arange(len(target)), target]
        
        # Calculating alpha, focal_loss and CE
        alpha = - self.weight 
        alpha_weight = alpha[target]
        focal_loss = (1 - pt) ** self.gamma 
        ce = torch.log(pt) #cross entropy loss for each datapoint, datapoint #1: -2.8154, datapoint #2: -5.0757, datapoint #3: -3.1886, datapoint #4 -1.4541

        loss = torch.sum(alpha_weight * focal_loss * ce)/len(target)

        #############################################################################
        #                              END OF YOUR CODE                             #
        #############################################################################
        return loss
